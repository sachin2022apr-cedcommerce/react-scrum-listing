import React from 'react'

export default function All() {
  return (
    <div>All</div>
  )
}
