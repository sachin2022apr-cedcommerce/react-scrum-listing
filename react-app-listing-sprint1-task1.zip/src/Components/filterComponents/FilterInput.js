import { TextField } from '@shopify/polaris'
import React from 'react'
import { connect } from 'react-redux';
import { tableFilter } from '../../Redux/actions';

<<<<<<< HEAD
function FilterInput({state, tableFilter, property, type, index}) {
    console.log(state);
=======
function FilterInput({tableFilter, property, type, index}) {
>>>>>>> b0b5b80903d6e7b37f39b3f6589b97dcb039c25a
    return (
        <>
            <TextField 
            onChange={(value) => {
                tableFilter({
                    property: property, 
                    type: type,
                    value: value,
                    index: index
                })
            }}
<<<<<<< HEAD
            value= {
                type === 'value'? state.filter[index]?.value : state.filter[index]?.condition
            }
=======
>>>>>>> b0b5b80903d6e7b37f39b3f6589b97dcb039c25a
            />
        </>
    )
}

const MapStateToProps = (state) => {
    return {
<<<<<<< HEAD
        state: state.dataTable
=======
        state: state
>>>>>>> b0b5b80903d6e7b37f39b3f6589b97dcb039c25a
    }
}
const MapDispatchToProps = (dispatch) => {
    return {
        tableFilter: (value) => dispatch(tableFilter(value))
    }
}
export default connect(MapStateToProps, MapDispatchToProps)(FilterInput)
