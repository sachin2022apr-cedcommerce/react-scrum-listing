// login user
export const getUser=()=>{
    return{
        type:"ADD_USER"
    }
}

// logout user
export const LogoutUser=()=>{
    return{
        type:"LOGOUT"
    }
}

export const tableFilter = (a) => {
    return{
        type:"TABLE_FILTER",
        payload:a
    }
}
<<<<<<< HEAD
=======

>>>>>>> b0b5b80903d6e7b37f39b3f6589b97dcb039c25a
